import Vue from 'vue'
import VueRouter from 'vue-router'
import VistaArtistas from '../views/VistaArtistas.vue'
import VistaDiscos from '../views/VistaDiscos.vue'
import VistaApi from '../views/VistaApi.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'artistas',
    component: VistaArtistas
  },
  {
    path: '/discos',
    name: 'discos',
    component: VistaDiscos
  },
  {
    path: '/api',
    name: 'api',
    component: VistaApi
  }
]

const router = new VueRouter({
  routes
})

export default router
