import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    artistasList:[ 
      {
        id:0,
        name:'Michael Jackson',
        genero:'Pop/rock',
        photo:'https://media.revistavanityfair.es/photos/60e848c79bf55ca1055abe4c/16:9/w_1792,h_1008,c_limit/50562.jpg',
        biografia:'Michael Jackson fue un cantante, productor, bailarín e icono pop, uno de los artistas más importantes del S. XX. Su éxito y relevancia le valió el apodo de “rey del pop”. Nació en 1958 en Indiana, en el seno de una familia afrodescendiente con diez hijos, entre ellos La Toya y Janet Jackson.'
      },
      {
        id:1,
        name:'Ice Cube',
        genero:'Hip-hop/Rap',
        photo:'https://3.bp.blogspot.com/-IzyJersb7-U/WWcuVBJNFSI/AAAAAAAA6Wk/eWwALqRDG7ABltZzn5_jZctHI8nAxsKugCLcBGAs/s1600/custom5ac0e0257cd76763ee41bfacf73f27fb.JPG',
        biografia:"O'Shea Jackson, conocido artísticamente como Ice Cube, nació en South Central, Los Ángeles, California, 15 de junio de 1969 Comenzó su carrera como miembro del polémico grupo de Gangsta rap N.W.A., y posteriormente lanzaría su exitosa carrera en solitario en la música y en el cine."
      },
      {
        id:2,
        name:'Eminem',
        genero:'Hip-hop/Rap',
        photo:'https://wallpapersmug.com/download/1600x900/67cef7/bw-eminem-hood.jpg',
        biografia:'Marshall Bruce Mathers III (17 de octubre de 1972, St. Joseph, Missouri), más conocido por su nombre artístico, Eminem, es un cantante y compositor norteamericano, una de las principales estrellas de la historia del rap. Eminem nació en una familia desestructurada.'
      }, 
    ],
    discosList:[ 
      {
        id:0,
        name:'Thriller',
        ventas:'70 millones',
        photo:'https://e00-elmundo.uecdn.es/elmundo/imagenes/2012/12/11/cultura/1355255478_0.jpg',
        autor:'Michael Jackson'
      },
      {
        id:1,
        name:'The predator',
        ventas:'2,2 millones',
        photo:'https://is1-ssl.mzstatic.com/image/thumb/Music115/v4/be/93/4c/be934cc0-3e4e-6676-5d7b-e5ddebe369d6/00602547276704.rgb.jpg/1200x1200bf-60.jpg',
        autor:"Ice Cube"
      },
      {
        id:2,
        name:'The Eminem Show',
        ventas:'9,8 millones',
        photo:'https://cdns-images.dzcdn.net/images/cover/cb0ce44e68a08568d837518c7ae7d1e3/500x500.jpg',
        autor:'Eminem'
      }, 
    ],
  },
  getters: {
  },
  mutations: {
    aniadirArtista(state,usuario){
      state.artistasList.push(usuario)
    },
    editArtist(state,usuario){
      state.artistasList[usuario.id]=usuario
    },
    aniadirDisco(state,disco){
      state.discosList.push(disco)
    },
    editDisk(state,disco){
      state.discosList[disco.id]=disco
    },
  },
  actions: {
    crearArtista(context,payload){
      context.commit("aniadirArtista",payload)
    },
    editarArtista(context,payload){
      context.commit("editArtist",payload)
    },
    crearDisco(context,payload){
      context.commit("aniadirDisco",payload)
    },
    editarDisco(context,payload){
      context.commit("editDisk",payload)
    }
  },
  modules: {
  }
})
