<template>
    <v-container>
        <v-container>
            <v-form @submit="editArtist()" v-show="mostrarFormularioEdicion">
                <v-card class="mx-auto" max-width="750" title="RegistarArtista">
                    <v-container>
                        <v-text-field v-model="editName" color="primary" label="Editar nombre del artista" variant="underlined"></v-text-field>
                        <v-text-field v-model="editGenero" color="primary" label="Editar género musical" variant="underlined"></v-text-field>
                        <v-text-field v-model="editBiografia" color="primary" label="Editar la biografía del artista" variant="underlined"></v-text-field>
                        <v-text-field v-model="editPhoto" color="primary" label="Link de la imagen" variant="underlined"></v-text-field>
                    </v-container>

                    <v-divider></v-divider>

                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="red" @click="descartarEdicion">Descartar edición</v-btn>
                        <v-btn color="success" type="submit">Editar Artista</v-btn> 
                    </v-card-actions>
                </v-card>
            </v-form>
        </v-container>
        <v-row>
            <v-col v-for="(artista,index) in artistasList" :key="index" cols="12" sm="4">
                <v-card class="mx-auto" max-width="350">
                    <v-img
                    class="align-end text-white"
                    height="215"
                    :src="artista.photo"
                    cover
                    >
                    </v-img>

                    <v-card-title v-text="artista.name"></v-card-title>

                    <v-card-subtitle class="pt-4">
                        Género musical:{{ artista.genero }}
                    </v-card-subtitle>

                    <v-card-text>
                        <div v-text="artista.biografia"></div>
                    </v-card-text>

                    <v-card-actions>
                    <v-btn color="green" @click="mostrarEdicionArtista(index)">
                        Editar Artista
                    </v-btn>

                    <v-btn color="red" @click="artistasList.splice(index,1)">
                        Borrar artista
                    </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
    </v-container> 
</template>
<script>
import {mapState,mapActions} from 'vuex'
    export default {
    name: 'artistas',
    computed:{
        ...mapState(['artistasList']),
    },
    data(){
        return{
            mostrarFormularioEdicion:false,
            editName:'',
            editGenero:'',
            editBiografia:'',
            editPhoto:'',
            editId:0,
        }
    },
    methods:{
        ...mapActions(['editarArtista']),
        mostrarEdicionArtista(index){
            this.mostrarFormularioEdicion=true,
            this.editName=this.$store.state.artistasList[index].name,
            this.editGenero=this.$store.state.artistasList[index].genero,
            this.editBiografia=this.$store.state.artistasList[index].biografia,
            this.editPhoto=this.$store.state.artistasList[index].photo
            this.editId=this.$store.state.artistasList[index].id
        },
        descartarEdicion(){
            this.mostrarFormularioEdicion=false
        },
        editArtist(){
            let artist = {
                name:this.editName,
                genero:this.editGenero, 
                photo:this.editPhoto,
                biografia:this.editBiografia,
                id:this.editId
            }
            this.editarArtista(artist)
            this.mostrarFormularioEdicion=false
        }
    }
       
  }
</script>