<template>
    <v-container>
        <v-container>
            <v-form @submit="editDisk()" v-show="mostrarFormularioEdicion">
                <v-card class="mx-auto" max-width="750" title="RegistarDisco">
                    <v-container>
                        <v-text-field v-model="editName" color="primary" label="Editar nombre del disco" variant="underlined"></v-text-field>
                        <v-text-field v-model="editVentas" color="primary" label="Editar nº de ventas" variant="underlined"></v-text-field>
                        <v-text-field v-model="editAutor" color="primary" label="Editar autor del disco" variant="underlined"></v-text-field>
                        <v-text-field v-model="editPhoto" color="primary" label="Link de la portada del disco" variant="underlined"></v-text-field>
                    </v-container>

                    <v-divider></v-divider>

                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="red" @click="descartarEdicion">Descartar edición</v-btn>
                        <v-btn color="success" type="submit">Editar Disco</v-btn> 
                    </v-card-actions>
                </v-card>
            </v-form>
        </v-container>
        <v-row>
            <v-col v-for="(disco,index) in discosList" :key="index" cols="12" sm="4">
                <v-card class="mx-auto" max-width="350">
                    <v-img
                    class="align-end text-white"
                    height="215"
                    :src="disco.photo"
                    cover
                    >
                    </v-img>

                    <v-card-title v-text="disco.name"></v-card-title>

                    <v-card-subtitle class="pt-4">
                        Copias vendidas: {{ disco.ventas }}
                    </v-card-subtitle>

                    <v-card-subtitle class="pt-4">
                        Autor: {{ disco.autor}}
                    </v-card-subtitle>

                    <v-card-actions>
                    <v-btn color="green" @click="mostrarEdicionDisco(index)">
                        Editar disco
                    </v-btn>

                    <v-btn color="red" @click="discosList.splice(index,1)">
                        Borrar disco
                    </v-btn>
                    </v-card-actions>
                </v-card>
            </v-col>
        </v-row>
    </v-container> 
</template>
<script>
import {mapState,mapActions} from 'vuex'
    export default {
        name: 'discos',
        computed:{
        ...mapState(['discosList']),
        },
        data(){
            return{
                mostrarFormularioEdicion:false,
                editName:'',
                editVentas:'',
                editAutor:'',
                editPhoto:'',
                editId:0,
            }
        },
        methods:{
            ...mapActions(['editarDisco']),
            mostrarEdicionDisco(index){
                this.mostrarFormularioEdicion=true,
                this.editName=this.$store.state.discosList[index].name,
                this.editVentas=this.$store.state.discosList[index].ventas,
                this.editAutor=this.$store.state.discosList[index].autor,
                this.editPhoto=this.$store.state.discosList[index].photo,
                this.editId=this.$store.state.discosList[index].id
            },
            descartarEdicion(){
                this.mostrarFormularioEdicion=false
            },
            editDisk(){
                let disk = {
                    name:this.editName,
                    ventas:this.editVentas, 
                    photo:this.editPhoto,
                    autor:this.editAutor,
                    id:this.editId
                }
                this.editarDisco(disk)
                this.mostrarFormularioEdicion=false
            }
        }
    }
</script>