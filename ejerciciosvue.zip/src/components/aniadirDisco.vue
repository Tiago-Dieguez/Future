<template>
    <v-container>  
        <v-container>
            <v-form @submit="saveDisk">
                <v-card class="mx-auto" max-width="400" title="RegistrarDisco">
                    <v-container>
                        <v-text-field v-model="name" color="primary" label="Nombre del Disco" variant="underlined"></v-text-field>
                        <v-text-field v-model="ventas" color="primary" label="Nº de copias vendidas" variant="underlined"></v-text-field>
                        <v-combobox label="Artista" :items="artistas" item-text="name" item-value="name" v-model="artista"></v-combobox>
                        <v-text-field v-model="photo" color="primary" label="Link de la portada del disco" variant="underlined"></v-text-field>
                    </v-container>

                    <v-divider></v-divider>

                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="success" type="submit">Registar Disco</v-btn>
                    </v-card-actions>
                </v-card>
            </v-form>  
        </v-container>    
    </v-container>
</template>
<script>
import {mapActions} from 'vuex'
export default {
    name: 'aniadirDisco',
    props:{

    },
        data(){
            return{
                name:'',
                ventas:'', 
                photo:'',
                autor:'',
                artista:'',
                artistas:[]
            }
        },
    components: {
        
    },
    
    methods:{
        ...mapActions(["crearDisco"]),
        cargarNombreArtistas(){
          this.artistas=this.$store.state.artistasList
        },
        saveDisk(){
            let disk = {
                name:this.name,
                ventas:this.ventas, 
                photo:this.photo,
                autor:this.artista.name,
                id:this.$store.state.discosList.length
            }
            this.crearDisco(disk)
            this.name=''
            this.ventas=''
            this.photo=''
            this.autor=''
            alert("Disco agregado con éxito")

        }
    },
    mounted (){
        this.artistas
        this.cargarNombreArtistas()
    },
  }
</script>