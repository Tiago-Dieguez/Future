<template>
    <v-container>  
        <v-container>
            <v-form @submit="saveArtist">
                <v-card class="mx-auto" max-width="400" title="RegistarArtista">
                    <v-container>
                        <v-text-field v-model="name" color="primary" label="Nombre del artista" variant="underlined"></v-text-field>
                        <v-text-field v-model="genero" color="primary" label="Género musical" variant="underlined"></v-text-field>
                        <v-text-field v-model="biografia" color="primary" label="Pequeña biografía del artista" variant="underlined"></v-text-field>
                        <v-text-field v-model="photo" color="primary" label="Link de la imagen" variant="underlined"></v-text-field>
                    </v-container>

                    <v-divider></v-divider>

                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn color="success" type="submit">Registar Artista</v-btn>
                    </v-card-actions>
                </v-card>
            </v-form>  
        </v-container>    
    </v-container>
</template>
<script>
import {mapActions} from 'vuex'
export default {
    name: 'aniadirArtista',
        data(){
            return{
                name :'',
                genero:'', 
                photo:'',
                biografia:'',
            }
        },
    methods:{
        ...mapActions(["crearArtista"]),
        saveArtist(){
            let artist = {
                name:this.name,
                genero:this.genero, 
                photo:this.photo,
                biografia:this.biografia,
                id:this.$store.state.artistasList.length
            }
            this.crearArtista(artist)
            this.name=''
            this.genero=''
            this.photo=''
            this.biografia=''
            alert("Artista agregado con éxito")

        }
    }
  }
</script>