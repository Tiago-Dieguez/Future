<template>
  <v-app>
    <v-card align-center>
      <v-tabs color="deep-purple-accent-4" align-tabs="center">
        <v-tab><router-link to="/">Artistas</router-link></v-tab>
        <v-tab><router-link to="/discos">Discos</router-link></v-tab>
        <v-tab><router-link to="/Api">Api</router-link></v-tab>
      </v-tabs>
    </v-card>  
    <v-main>
      <router-view></router-view>
    </v-main>
  </v-app>
</template>

<script setup>
  import { ref } from 'vue'
</script>

<script>
  export default {
    
  }
</script>
