<template>
    <v-container>
        <v-btn @click="getPersonas">Pulsa y observa</v-btn>
        <v-container>
            <v-row>
                <v-col v-for="(persona,index) in personas" :key="index" cols="12" sm="6">
                    <v-card class="mx-auto" max-width="350">
                        <v-img
                        class="align-end text-white"
                        height="355"
                        :src="persona.image"
                        cover
                        >
                        </v-img>

                        <v-card-title v-text="persona.name"></v-card-title>

                        <v-card-subtitle class="pt-4">
                            Gender:{{ persona.gender }}
                        </v-card-subtitle>
                        <v-card-subtitle class="pt-4">
                            House:{{ persona.house }}
                        </v-card-subtitle> 
                    </v-card>
                </v-col>
            </v-row>
        </v-container>
    </v-container>
</template>
<script>
    import axios from 'axios';
    export default {
    name: 'VistaApi',
        data(){
            return{
                personas:[]
            }
        },
    methods:{
        async getPersonas(){
           const respuesta= await axios.get("https://hp-api.onrender.com/api/characters/house/gryffindor")
           this.personas=respuesta.data
        }
    },
  }
</script>