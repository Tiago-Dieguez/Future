<template>
    <v-container>
        <v-container>
            <v-btn @click="toggleMostrarFormularioDiscos"><span v-text="textoBotonDiscos"></span></v-btn>
        </v-container>
        <aniadirDisco v-show="mostrarFormulario"/>
        <discos v-show="mostrarDiscos"/>
    </v-container>
</template>
<script>
    import discos from '@/components/discos.vue';
    import aniadirDisco from '@/components/aniadirDisco.vue';
    export default {
    name: 'VistaDiscos',
        data(){
            return{
                mostrarFormulario:false,
                mostrarDiscos:true,
                textoBotonDiscos:'+Añadir Disco'
            }
        },
    components: {
      discos,
      aniadirDisco,  
    },
    computed:{
        

    },
    methods:{
        toggleMostrarFormularioDiscos(){
            if (this.mostrarDiscos==false){
                this.textoBotonDiscos='+Añadir Disco'
            }
            else{
                this.textoBotonDiscos='Mostrar Discos'
            }
            this.mostrarFormulario=!this.mostrarFormulario
            this.mostrarDiscos=!this.mostrarDiscos
        }
    }
  }
</script>