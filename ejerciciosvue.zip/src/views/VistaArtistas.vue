<template>
    <v-container>
        <v-container>
            <v-btn @click="toggleMostrarFormularioArtista"><span v-text="textoBotonArtista"></span></v-btn>
        </v-container>
        <aniadirArtista v-show="mostrarFormulario"/>
        <artistas v-show="mostrarArtistas"/>
    </v-container>
</template>
<script>
    import artistas from '@/components/artistas.vue';
    import aniadirArtista from '@/components/aniadirArtista.vue';
    export default {
    name: 'VistaArtistas',
        data(){
            return{
                mostrarFormulario:false,
                mostrarArtistas:true,
                textoBotonArtista:'+Añadir artista'
            }
        },
    components: {
      artistas,
      aniadirArtista,  
    },
    computed:{
        

    },
    methods:{
        toggleMostrarFormularioArtista(){
            if (this.mostrarArtistas==false){
                this.textoBotonArtista='+Añadir artista'
            }
            else{
                this.textoBotonArtista='Mostrar artistas'
            }
            this.mostrarFormulario=!this.mostrarFormulario
            this.mostrarArtistas=!this.mostrarArtistas
        }
    }
  }
</script>